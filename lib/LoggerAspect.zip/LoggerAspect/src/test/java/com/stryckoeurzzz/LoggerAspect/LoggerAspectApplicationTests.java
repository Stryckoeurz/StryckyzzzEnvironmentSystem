package com.stryckoeurzzz.LoggerAspect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggerAspectApplicationTests {

	@Test
	void contextLoads() {
	}

}
